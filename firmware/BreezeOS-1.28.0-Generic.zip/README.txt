Breeze OS 1.28.0 通用固件（同款ESP32-S3 N16R8硬件）

此包不含个人WiFi默认值、API Key、设备NVS或SD个人文件。
已在IDF分区运行的设备：用BreezeOS-1.28.0-OTA.bin从热点网页上传，再在设置安装。
新板首次部署：将BreezeOS-1.28.0-Factory.bin从0x0烧录，16MB Flash、DIO、80MHz。
Factory是首次部署镜像，会覆盖配置区域，不要作为现有设备日常升级文件。

首次烧录示例（自行替换串口）：
python -m esptool --chip esp32s3 --port COM3 --baud 460800 write_flash --flash_mode dio --flash_freq 80m --flash_size 16MB 0x0 BreezeOS-1.28.0-Factory.bin

启动后从下拉栏开启热点，长按热点查看名称和密码，手机连接并打开设备显示的网址。
点击网页底部“服务配置”，分别填写自己的AI、天气/生活指数接口与Key，保存后点击“重启并生效”。
已有密钥不回显，留空保留。AI协议需兼容DeepSeek；天气协议需兼容心知。
服务配置不需要SD卡；音乐、语音完整缓存、字库和媒体仍使用SD运行资源。
配置保存设备NVS，断电保留。原有SD JSON导入仍支持，但不必使用。

OTA应用与Factory均为本版源码通用构建，不包含已配置设备的NVS备份。
